# Tinder-Clone
Hello everyone ,this is my first MERN Stack project. Here I had used  Reactjs framework in it, expressjs and in database I had used mongoDb part in it.
